BabyMonitor readme.

Download BabyMonitor.iff and place it in "C:\program files\maxis\the sims\downloads", or wherever your sims has been installed.

Place one baby monitor near the baby so it can pick up the sound when the baby cries. Place other baby monitors around the house where sims are likely to be spending time. When the baby cries, any Sim who is standing near any baby monitor will hear the baby and immediately be queued to come over and tend to it.

To uninstall the baby monitor, just delete the file BabyMonitor.iff.

For questions, comments, concerns, and suggestions, send e-mail to farbie_hoo@yahoo.com.
